const fs = require('fs');
const path = require('path');

// Load environment variables
require('dotenv').config();

// Simulate file processing
async function testFileProcessing() {
  console.log('🧪 Testing File Processing Workflow...\n');
  
  // Read the DOCX file
  const filePath = './test-ocean-requirements.docx';
  const fileBuffer = fs.readFileSync(filePath);
  const fileStats = fs.statSync(filePath);
  
  console.log('📁 File Information:');
  console.log(`- Name: ${path.basename(filePath)}`);
  console.log(`- Size: ${fileStats.size} bytes`);
  console.log(`- Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document\n`);
  
  // Test file validation
  const maxSize = 10 * 1024 * 1024; // 10MB
  const allowedTypes = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain',
    'text/csv',
    'image/jpeg',
    'image/png',
    'image/gif'
  ];
  
  const fileType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
  
  console.log('✅ Validation Results:');
  console.log(`- Size check: ${fileStats.size <= maxSize ? 'PASSED' : 'FAILED'}`);
  console.log(`- Type check: ${allowedTypes.includes(fileType) ? 'PASSED' : 'FAILED'}\n`);
  
  // Simulate DOCX processing (base64 encoding)
  const base64Content = fileBuffer.toString('base64');
  const dataUri = `data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,${base64Content}`;
  
  console.log('📄 File Processing Results:');
  console.log(`- Base64 length: ${base64Content.length} characters`);
  console.log(`- Data URI format: ${dataUri.substring(0, 100)}...`);
  console.log(`- Ready for AI processing: ✅\n`);
  
  return dataUri;
}

// Test AI document analysis
async function testAIDocumentAnalysis(dataUri) {
  console.log('🤖 Testing AI Document Analysis...\n');
  
  const apiKey = process.env.ABACUSAI_API_KEY;
  
  const requestData = {
    model: 'gpt-4.1-mini',
    messages: [
      {
        role: 'system',
        content: 'Extract and summarize security-relevant information from the provided document. Focus on system architecture, data flows, user interactions, external dependencies, and potential attack surfaces. Provide a clear, structured summary that can be used for threat modeling.'
      },
      {
        role: 'user',
        content: [
          { type: "text", text: "Please analyze this healthcare system requirements document for security-relevant information:" },
          { type: "file", file: { filename: "ocean-requirements.docx", file_data: dataUri } }
        ]
      }
    ],
    temperature: 0.3,
  };

  const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestData),
  });

  if (!response.ok) {
    throw new Error(`AI document analysis failed: ${response.statusText}`);
  }

  const result = await response.json();
  const analysis = result.choices[0].message.content;
  
  console.log('📊 Document Analysis Result:');
  console.log(analysis);
  console.log('\n✅ Document analysis completed successfully!\n');
  
  return analysis;
}

// Test AI threat modeling
async function testAIThreatModeling(documentAnalysis) {
  console.log('🛡️ Testing AI Threat Modeling...\n');
  
  const apiKey = process.env.ABACUSAI_API_KEY;
  
  const systemPrompt = `You are a cybersecurity expert specializing in threat modeling using the STRIDE methodology. 
      
      Analyze the provided system description and identify potential security threats categorized by STRIDE:
      - Spoofing: Identity spoofing threats
      - Tampering: Data or system integrity threats  
      - Repudiation: Non-repudiation threats
      - Information Disclosure: Confidentiality threats
      - Denial of Service: Availability threats
      - Elevation of Privilege: Authorization threats

      For each identified threat, provide:
      1. Clear title and description
      2. Severity level (LOW, MEDIUM, HIGH, CRITICAL)
      3. Specific recommendation for mitigation
      4. Technical implementation details

      Respond with structured JSON containing summary, strideAnalysis array, recommendations, and technicalAssumptions.`;

  const userPrompt = `System Description: Healthcare referral system that processes patient data from Ocean platform to CHRIS sites via fax integration

Additional Context from Documents:
${documentAnalysis}`;

  const requestData = {
    model: 'gpt-4.1-mini',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ],
    response_format: { type: "json_object" },
    temperature: 0.3,
  };

  const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestData),
  });

  if (!response.ok) {
    throw new Error(`AI threat modeling failed: ${response.statusText}`);
  }

  const result = await response.json();
  const threatAnalysis = JSON.parse(result.choices[0].message.content);
  
  console.log('🎯 Threat Modeling Result:');
  console.log(`Summary: ${threatAnalysis.summary}`);
  console.log(`STRIDE Categories: ${threatAnalysis.strideAnalysis?.length || 0}`);
  
  if (threatAnalysis.strideAnalysis) {
    threatAnalysis.strideAnalysis.forEach(category => {
      console.log(`\n📋 ${category.category}:`);
      category.threats.forEach((threat, index) => {
        console.log(`  ${index + 1}. ${threat.title} (${threat.severity})`);
        console.log(`     ${threat.description}`);
      });
    });
  }
  
  console.log('\n✅ Threat modeling completed successfully!\n');
  
  return threatAnalysis;
}

// Run the complete test
async function runCompleteTest() {
  try {
    console.log('🚀 Starting Complete BGuard Suite TMaaS Test\n');
    console.log('=' * 60 + '\n');
    
    // Test 1: File Processing
    const dataUri = await testFileProcessing();
    
    // Test 2: AI Document Analysis  
    const documentAnalysis = await testAIDocumentAnalysis(dataUri);
    
    // Test 3: AI Threat Modeling
    const threatAnalysis = await testAIThreatModeling(documentAnalysis);
    
    console.log('🎉 ALL TESTS COMPLETED SUCCESSFULLY!');
    console.log('✅ File upload: Working');
    console.log('✅ Document processing: Working');
    console.log('✅ AI document analysis: Working');
    console.log('✅ AI threat modeling: Working');
    console.log('\nThe BGuard Suite TMaaS application is fully functional! 🛡️');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
  }
}

// Add fetch polyfill for Node.js
if (typeof fetch === 'undefined') {
  global.fetch = require('node-fetch');
}

runCompleteTest();

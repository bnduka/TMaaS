
'use client';

import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  Shield,
  BarChart3,
  Search,
  FileText,
  Activity,
  Lock,
  Crown,
  KeyRound,
  Building2,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  Home
} from 'lucide-react';
import { useState } from 'react';

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const { data: session } = useSession();
  const pathname = usePathname();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  // Role-based navigation items
  const getNavigationItems = (userRole: string) => {
    const baseItems = [
      { name: 'Dashboard', href: '/dashboard', icon: BarChart3 },
      { name: 'Threat Models', href: '/threat-models', icon: Shield },
      { name: 'Findings', href: '/findings', icon: Search },
      { name: 'Reports', href: '/reports', icon: FileText },
    ];

    const businessAdminItems = [
      { name: 'Organization Admin', href: '/business-admin', icon: Building2 },
      { name: 'Org Security', href: '/business-admin/security', icon: KeyRound },
    ];

    const adminItems = [
      { name: 'Platform Admin', href: '/admin', icon: Crown },
      { name: 'Platform Security', href: '/admin/security', icon: KeyRound },
    ];

    switch (userRole) {
      case 'ADMIN':
        return [...baseItems, ...businessAdminItems, ...adminItems];
      case 'BUSINESS_ADMIN':
        return [...baseItems, ...businessAdminItems];
      case 'BUSINESS_USER':
      case 'USER':
      default:
        return baseItems;
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return { text: 'Platform Admin', color: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' };
      case 'BUSINESS_ADMIN':
        return { text: 'Org Admin', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' };
      case 'BUSINESS_USER':
        return { text: 'Business User', color: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' };
      case 'USER':
        return { text: 'User', color: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200' };
      default:
        return null;
    }
  };

  const navigationItems = session?.user ? getNavigationItems(session.user.role) : [];

  if (!session?.user) {
    return null;
  }

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex h-16 items-center border-b px-4">
        <Link href="/" className="flex items-center space-x-2">
          <Shield className="h-8 w-8 text-blue-600" />
          {!isCollapsed && (
            <span className="text-xl font-bold text-gradient">BGuard Suite</span>
          )}
        </Link>
        {!isCollapsed && (
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto lg:hidden"
            onClick={() => setIsMobileOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* User Info */}
      {!isCollapsed && (
        <div className="border-b p-4">
          <div className="space-y-2">
            <p className="text-sm font-medium leading-none">
              {session.user.name || 'User'}
            </p>
            <p className="text-xs text-muted-foreground">
              {session.user.email}
            </p>
            
            {/* Role Badge */}
            {(() => {
              const roleBadge = getRoleBadge(session.user.role);
              return roleBadge ? (
                <Badge variant="outline" className={`w-fit text-xs ${roleBadge.color}`}>
                  {roleBadge.text}
                </Badge>
              ) : null;
            })()}
            
            {/* Organization Context */}
            {session.user.organizationName && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Building2 className="h-3 w-3" />
                <span className="truncate">{session.user.organizationName}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Navigation */}
      <ScrollArea className="flex-1 px-3 py-4">
        <div className="space-y-2">
          {/* Home Link */}
          <Link href="/">
            <Button
              variant={pathname === '/' ? 'secondary' : 'ghost'}
              className={cn(
                'w-full justify-start',
                isCollapsed && 'px-2'
              )}
            >
              <Home className="h-4 w-4" />
              {!isCollapsed && <span className="ml-2">Home</span>}
            </Button>
          </Link>

          <Separator className="my-2" />

          {/* Main Navigation */}
          {navigationItems.map((item) => (
            <Link key={item.name} href={item.href}>
              <Button
                variant={pathname === item.href ? 'secondary' : 'ghost'}
                className={cn(
                  'w-full justify-start',
                  isCollapsed && 'px-2'
                )}
              >
                <item.icon className="h-4 w-4" />
                {!isCollapsed && <span className="ml-2">{item.name}</span>}
              </Button>
            </Link>
          ))}
        </div>
      </ScrollArea>

      {/* Collapse Toggle */}
      <div className="border-t p-2">
        <Button
          variant="ghost"
          size="sm"
          className="hidden lg:flex w-full justify-center"
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          {isCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4" />
              <span className="ml-2">Collapse</span>
            </>
          )}
        </Button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <div
        className={cn(
          'hidden lg:flex h-screen flex-col border-r bg-background transition-all duration-300',
          isCollapsed ? 'w-16' : 'w-64',
          className
        )}
      >
        <SidebarContent />
      </div>

      {/* Mobile Sidebar */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-black/50"
            onClick={() => setIsMobileOpen(false)}
          />
          <div className="fixed left-0 top-0 h-full w-64 bg-background border-r">
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Mobile Menu Button */}
      <Button
        variant="outline"
        size="sm"
        className="fixed top-4 left-4 z-40 lg:hidden"
        onClick={() => setIsMobileOpen(true)}
      >
        <Menu className="h-4 w-4" />
      </Button>
    </>
  );
}


import { ThreatModel, Finding, Report, FileUpload, User, ThreatModelStatus, FindingStatus, Severity, StrideCategory, ReportFormat, UserRole } from '@prisma/client';

export type ThreatModelWithDetails = ThreatModel & {
  user: User;
  findings: Finding[];
  reports: Report[];
  fileUploads: FileUpload[];
};

export type FindingWithDetails = Finding & {
  user: User;
  threatModel: ThreatModel;
};

export type ReportWithDetails = Report & {
  user: User;
  threatModel: ThreatModel;
};

export interface StrideAnalysis {
  category: StrideCategory;
  threats: ThreatAnalysis[];
}

export interface ThreatAnalysis {
  title: string;
  description: string;
  severity: Severity;
  recommendation: string;
  mitigation: string;
}

export interface ThreatModelRequest {
  name: string;
  description?: string;
  prompt: string;
  fileIds?: string[];
}

export interface AIAnalysisResponse {
  summary: string;
  strideAnalysis: StrideAnalysis[];
  recommendations: string[];
  technicalAssumptions: string[];
}

export {
  ThreatModelStatus,
  FindingStatus,
  Severity,
  StrideCategory,
  ReportFormat,
  UserRole
};

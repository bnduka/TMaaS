const https = require('https');

// Test AI service connectivity
async function testAIService() {
  const apiKey = process.env.ABACUSAI_API_KEY || '358cd30bec9543dda4ef62796652b3a6';
  
  const data = JSON.stringify({
    model: 'gpt-4.1-mini',
    messages: [
      {
        role: 'system',
        content: 'You are a cybersecurity expert. Respond with "AI Service is working" if you can process this request.'
      },
      {
        role: 'user',
        content: 'Test connectivity'
      }
    ],
    temperature: 0.3,
  });

  const options = {
    hostname: 'apps.abacus.ai',
    port: 443,
    path: '/v1/chat/completions',
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'Content-Length': data.length
    }
  };

  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const result = JSON.parse(responseData);
          if (res.statusCode === 200) {
            console.log('✅ AI Service Status: CONNECTED');
            console.log('Response:', result.choices[0].message.content);
            resolve(result);
          } else {
            console.log('❌ AI Service Error:', res.statusCode, result);
            reject(new Error(`HTTP ${res.statusCode}: ${JSON.stringify(result)}`));
          }
        } catch (error) {
          reject(new Error(`Parse error: ${error.message}`));
        }
      });
    });

    req.on('error', (error) => {
      console.log('❌ Connection Error:', error.message);
      reject(error);
    });

    req.write(data);
    req.end();
  });
}

// Load environment variables from .env file
require('dotenv').config();

console.log('Testing AI Service Connectivity...');
testAIService()
  .then(() => {
    console.log('✅ AI Service test completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ AI Service test failed:', error.message);
    process.exit(1);
  });

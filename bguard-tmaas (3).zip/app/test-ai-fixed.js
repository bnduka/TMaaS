// Load environment variables
require('dotenv').config();

// Add fetch polyfill for Node.js
if (typeof fetch === 'undefined') {
  global.fetch = require('node-fetch');
}

// Function to clean JSON response from markdown
function cleanJsonResponse(content) {
  // Remove markdown code blocks
  let cleaned = content.replace(/```json\s*/g, '').replace(/```\s*/g, '');
  // Remove any leading/trailing whitespace
  cleaned = cleaned.trim();
  return cleaned;
}

// Test AI threat modeling with just our extracted text content
async function testThreatModeling() {
  console.log('🛡️ Testing AI Threat Modeling with Ocean Requirements...\n');
  
  const apiKey = process.env.ABACUSAI_API_KEY;
  
  // Load our extracted text content
  const fs = require('fs');
  const oceanContent = fs.readFileSync('/home/ubuntu/bguard-tmaas/ocean-requirements-text.txt', 'utf8');
  
  const systemPrompt = `You are a cybersecurity expert specializing in threat modeling using the STRIDE methodology. 
      
      Analyze the provided system description and identify potential security threats categorized by STRIDE:
      - Spoofing: Identity spoofing threats
      - Tampering: Data or system integrity threats  
      - Repudiation: Non-repudiation threats
      - Information Disclosure: Confidentiality threats
      - Denial of Service: Availability threats
      - Elevation of Privilege: Authorization threats

      For each identified threat, provide:
      1. Clear title and description
      2. Severity level (LOW, MEDIUM, HIGH, CRITICAL)
      3. Specific recommendation for mitigation

      Respond with clean JSON only, no markdown formatting. Use this structure:
      {
        "summary": "Brief analysis summary",
        "strideAnalysis": [
          {
            "category": "SPOOFING", 
            "threats": [
              {
                "title": "Threat name",
                "description": "Threat description", 
                "severity": "HIGH",
                "recommendation": "Mitigation recommendation"
              }
            ]
          }
        ],
        "recommendations": ["General recommendation 1", "General recommendation 2"],
        "technicalAssumptions": ["Assumption 1", "Assumption 2"]
      }`;

  const userPrompt = `System Description: Healthcare referral system that processes patient data from Ocean platform to CHRIS sites via fax integration.

Key Technical Details:
- Processes encrypted patient referrals from Ocean API
- Decrypts referral data and attachments using one-time keys
- Maintains site_id to fax_number mapping for CHRIS sites  
- Sends referral documents via Etherfax integration
- Uses ledger IDs as MRN/Patient identifiers
- Handles PHI (Protected Health Information)
- Microservices architecture with Kafka messaging
- API webhooks for Ocean integration
- Database storage for transaction ledgers

Technical Flow:
${oceanContent.substring(0, 2000)}`;

  const requestData = {
    model: 'gpt-4.1-mini',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ],
    response_format: { type: "json_object" },
    temperature: 0.3,
  };

  console.log('📤 Sending request to AI service...');
  
  const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestData),
  });

  console.log(`📥 Response status: ${response.status} ${response.statusText}`);

  if (!response.ok) {
    const errorText = await response.text();
    console.error('❌ Error response:', errorText);
    throw new Error(`AI threat modeling failed: ${response.statusText}`);
  }

  const result = await response.json();
  const rawContent = result.choices[0].message.content;
  
  console.log('🧹 Cleaning AI response...');
  
  // Clean the response to remove markdown formatting
  const cleanedContent = cleanJsonResponse(rawContent);
  
  let threatAnalysis;
  try {
    threatAnalysis = JSON.parse(cleanedContent);
  } catch (parseError) {
    console.error('❌ JSON Parse Error. Raw content:');
    console.error(rawContent);
    throw new Error(`Failed to parse AI response: ${parseError.message}`);
  }
  
  console.log('\n🎯 STRIDE Threat Analysis Results:');
  console.log('=' * 50);
  console.log(`📝 Summary: ${threatAnalysis.summary}`);
  console.log(`🛡️ STRIDE Categories Analyzed: ${threatAnalysis.strideAnalysis?.length || 0}`);
  
  let totalThreats = 0;
  if (threatAnalysis.strideAnalysis) {
    threatAnalysis.strideAnalysis.forEach(category => {
      const threatCount = category.threats?.length || 0;
      totalThreats += threatCount;
      console.log(`\n📋 ${category.category}: ${threatCount} threats identified`);
      
      if (category.threats) {
        category.threats.forEach((threat, index) => {
          console.log(`  ${index + 1}. 🚨 ${threat.title} [${threat.severity}]`);
          console.log(`     📄 ${threat.description}`);
          console.log(`     💡 Recommendation: ${threat.recommendation}`);
          console.log('');
        });
      }
    });
  }
  
  console.log(`\n📊 Total Threats Identified: ${totalThreats}`);
  
  if (threatAnalysis.recommendations) {
    console.log('\n🎯 General Security Recommendations:');
    threatAnalysis.recommendations.forEach((rec, index) => {
      console.log(`  ${index + 1}. ${rec}`);
    });
  }
  
  if (threatAnalysis.technicalAssumptions) {
    console.log('\n🔧 Technical Assumptions:');
    threatAnalysis.technicalAssumptions.forEach((assumption, index) => {
      console.log(`  ${index + 1}. ${assumption}`);
    });
  }
  
  console.log('\n✅ AI-Powered STRIDE Analysis completed successfully!');
  
  return threatAnalysis;
}

// Run the test
testThreatModeling()
  .then((result) => {
    console.log('\n🎉 THREAT MODELING TEST COMPLETED SUCCESSFULLY!');
    console.log('✅ AI Service: Working');
    console.log('✅ STRIDE Analysis: Working'); 
    console.log('✅ JSON Response Parsing: Working');
    console.log('✅ Healthcare System Analysis: Working');
    console.log('\n🛡️ The BGuard Suite TMaaS AI-powered threat modeling is fully functional!');
  })
  .catch((error) => {
    console.error('❌ Threat modeling test failed:', error.message);
    if (error.stack) console.error('Stack trace:', error.stack);
  });

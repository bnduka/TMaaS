
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { logActivity } from '@/lib/activity-logger';

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if user is admin
    const currentUser = await prisma.user.findUnique({
      where: { id: session.user.id },
    });

    if (currentUser?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden - Admin access required' }, { status: 403 });
    }

    const userId = params.id;
    const body = await request.json();
    const { role, billingStatus } = body;

    // Validate input
    if (role && !['USER', 'ADMIN'].includes(role)) {
      return NextResponse.json({ error: 'Invalid role' }, { status: 400 });
    }

    if (billingStatus && !['ACTIVE', 'SUSPENDED', 'TRIAL', 'EXPIRED'].includes(billingStatus)) {
      return NextResponse.json({ error: 'Invalid billing status' }, { status: 400 });
    }

    // Prevent admin from demoting themselves
    if (userId === session.user.id && role === 'USER') {
      return NextResponse.json({ 
        error: 'Cannot change your own role from admin to user' 
      }, { status: 400 });
    }

    // Check if target user exists
    const targetUser = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!targetUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Update user
    const updateData: any = {};
    if (role !== undefined) updateData.role = role;
    if (billingStatus !== undefined) updateData.billingStatus = billingStatus;

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: updateData,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        billingStatus: true,
        lastLoginAt: true,
        createdAt: true,
      },
    });

    // Log the activity
    await logActivity({
      userId: session.user.id,
      action: 'ADMIN_UPDATE_USER',
      status: 'SUCCESS',
      description: `Updated user ${targetUser.email}: role=${role || 'unchanged'}, billing=${billingStatus || 'unchanged'}`,
      entityType: 'user',
      entityId: userId,
    });

    return NextResponse.json({ user: updatedUser });
  } catch (error: any) {
    console.error('Error updating user:', error);
    
    // Log the failed activity
    const session = await getServerSession(authOptions);
    if (session?.user?.id) {
      await logActivity({
        userId: session.user.id,
        action: 'ADMIN_UPDATE_USER',
        status: 'FAILED',
        description: 'Failed to update user',
        errorMessage: error.message,
      });
    }

    return NextResponse.json(
      { error: 'Failed to update user' },
      { status: 500 }
    );
  }
}

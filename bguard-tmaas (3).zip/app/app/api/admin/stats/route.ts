
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get overall stats
    const [totalUsers, totalThreatModels, totalFindings, totalReports] = await Promise.all([
      prisma.user.count(),
      prisma.threatModel.count(),
      prisma.finding.count(),
      prisma.report.count(),
    ]);

    // Get user-specific stats if not admin
    let userStats = {};
    if (session.user.role !== 'ADMIN') {
      const [userThreatModels, userFindings, userReports, openFindings] = await Promise.all([
        prisma.threatModel.count({ where: { userId: session.user.id } }),
        prisma.finding.count({ where: { userId: session.user.id } }),
        prisma.report.count({ where: { userId: session.user.id } }),
        prisma.finding.count({ 
          where: { 
            userId: session.user.id,
            status: 'OPEN'
          } 
        }),
      ]);

      userStats = {
        totalThreatModels: userThreatModels,
        totalFindings: userFindings,
        totalReports: userReports,
        openFindings,
      };
    } else {
      // For admin, show global stats
      const openFindings = await prisma.finding.count({ 
        where: { status: 'OPEN' } 
      });

      userStats = {
        totalThreatModels,
        totalFindings,
        totalReports,
        openFindings,
      };
    }

    // Get recent admin stats for trends (admin only)
    let adminStats: any[] = [];
    if (session.user.role === 'ADMIN') {
      adminStats = await prisma.adminStats.findMany({
        orderBy: { date: 'desc' },
        take: 30,
      });
    }

    return NextResponse.json({
      ...userStats,
      adminStats: session.user.role === 'ADMIN' ? adminStats : [],
      globalStats: session.user.role === 'ADMIN' ? {
        totalUsers,
        totalThreatModels,
        totalFindings,
        totalReports,
      } : null,
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

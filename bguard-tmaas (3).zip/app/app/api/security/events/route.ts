
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { SecurityEventService } from '@/lib/security/security-events';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');

    // Regular users can only see their own events
    // Admins and business admins can see org events
    let events;
    
    if (session.user.role === 'ADMIN') {
      // Platform admin sees all events
      events = await SecurityEventService.getAllSecurityEvents({ limit });
    } else if (session.user.role === 'BUSINESS_ADMIN' && session.user.organizationId) {
      // Business admin sees organization events
      events = await SecurityEventService.getAllSecurityEvents({
        limit,
      });
      // Filter by organization in the service
    } else {
      // Regular users see only their events
      events = await SecurityEventService.getUserSecurityEvents(session.user.id, limit);
    }
    
    return NextResponse.json({ events });
  } catch (error) {
    console.error('Get security events error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch security events' },
      { status: 500 }
    );
  }
}

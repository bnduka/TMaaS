
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { ReportGenerator } from '@/lib/report-generator';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const threatModelId = searchParams.get('threatModelId');

    let whereClause: any = {};
    
    if (threatModelId) {
      // If querying by threat model ID, check permissions
      const userRole = session.user.role;
      
      if (userRole === 'ADMIN') {
        // Platform admin can access any threat model's reports
        whereClause = { threatModelId };
      } else if (userRole === 'BUSINESS_ADMIN') {
        // Business admin can access reports from their organization
        whereClause = {
          threatModelId,
          user: {
            organizationId: session.user.organizationId
          }
        };
      } else {
        // Regular users can only access their own reports
        whereClause = {
          threatModelId,
          userId: session.user.id
        };
      }
    } else {
      // Default behavior: get user's own reports
      whereClause = { userId: session.user.id };
    }

    const reports = await prisma.report.findMany({
      where: whereClause,
      include: {
        user: true,
        threatModel: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ reports });
  } catch (error) {
    console.error('Error fetching reports:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { threatModelId, format } = await request.json();

    if (!threatModelId || !format) {
      return NextResponse.json(
        { error: 'Threat model ID and format are required' },
        { status: 400 }
      );
    }

    // Get threat model with all related data
    const threatModel = await prisma.threatModel.findFirst({
      where: { 
        id: threatModelId,
        userId: session.user.id 
      },
      include: {
        user: true,
        findings: true,
        reports: true,
        fileUploads: true,
      },
    });

    if (!threatModel) {
      return NextResponse.json({ error: 'Threat model not found' }, { status: 404 });
    }

    // Generate report content
    let content: string;
    let fileSize: number;

    if (format === 'HTML') {
      content = ReportGenerator.generateHtmlReport(threatModel, 'AI-powered threat analysis completed using STRIDE methodology.');
      fileSize = Buffer.byteLength(content, 'utf8');
    } else {
      // For PDF, we'll store the text content and indicate it needs PDF generation
      content = ReportGenerator.generateTextContent(threatModel);
      fileSize = Buffer.byteLength(content, 'utf8');
    }

    // Create report record
    const report = await prisma.report.create({
      data: {
        name: `${threatModel.name} - Threat Analysis Report`,
        format,
        content,
        fileSize,
        userId: session.user.id,
        threatModelId,
      },
      include: {
        user: true,
        threatModel: true,
      },
    });

    return NextResponse.json({ report }, { status: 201 });
  } catch (error) {
    console.error('Error creating report:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

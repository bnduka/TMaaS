
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { logActivity } from '@/lib/activity-logger';
import { UserRole } from '@prisma/client';

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const reportId = params.id;
    const userRole = session.user.role as UserRole;

    // Only ADMIN and BUSINESS_ADMIN can delete reports
    if (userRole !== 'ADMIN' && userRole !== 'BUSINESS_ADMIN') {
      return NextResponse.json({ error: 'Insufficient permissions' }, { status: 403 });
    }

    // Check if report exists
    const report = await prisma.report.findUnique({
      where: { id: reportId },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            organizationId: true
          }
        },
        threatModel: {
          select: {
            id: true,
            name: true
          }
        }
      }
    });

    if (!report) {
      return NextResponse.json({ error: 'Report not found' }, { status: 404 });
    }

    // For BUSINESS_ADMIN, check if they can delete this report (same organization)
    if (userRole === 'BUSINESS_ADMIN') {
      if (session.user.organizationId !== report.user.organizationId) {
        return NextResponse.json({ error: 'Cannot delete reports from other organizations' }, { status: 403 });
      }
    }

    // Delete the report
    await prisma.report.delete({
      where: { id: reportId }
    });

    // Log the activity
    await logActivity({
      userId: session.user.id!,
      action: 'DELETE_REPORT',
      status: 'SUCCESS',
      description: 'Admin deleted a report',
      details: `Deleted report ${report.name} (ID: ${report.id}) for threat model ${report.threatModel?.name} (ID: ${report.threatModel?.id}). Original user: ${report.user.email}`
    });

    return NextResponse.json({ 
      message: 'Report deleted successfully',
      reportId: report.id 
    });

  } catch (error) {
    console.error('Error deleting report:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

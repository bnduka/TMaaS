
import { NextRequest, NextResponse } from 'next/server';
import { EmailVerificationService } from '@/lib/security/email-verification';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const token = searchParams.get('token');
    
    if (!token) {
      return NextResponse.redirect(new URL('/auth/verify-email?error=invalid_token', request.url));
    }

    const result = await EmailVerificationService.verifyEmail(token);
    
    if (result.success) {
      return NextResponse.redirect(new URL('/login?verified=true', request.url));
    } else {
      return NextResponse.redirect(new URL('/auth/verify-email?error=verification_failed', request.url));
    }
  } catch (error) {
    console.error('Email verification error:', error);
    return NextResponse.redirect(new URL('/auth/verify-email?error=server_error', request.url));
  }
}

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();
    
    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }

    const result = await EmailVerificationService.resendVerificationEmail(email);
    
    return NextResponse.json(result);
  } catch (error) {
    console.error('Resend verification error:', error);
    return NextResponse.json(
      { error: 'Failed to resend verification email' },
      { status: 500 }
    );
  }
}

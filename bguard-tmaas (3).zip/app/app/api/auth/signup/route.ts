
import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { getDefaultUserRole } from '@/lib/middleware-helpers';
import { logActivity } from '@/lib/activity-logger';
import { signupSchema } from '@/lib/validation/schemas';
import { createValidationMiddleware, createErrorResponse, createSuccessResponse, validateRateLimitHeaders } from '@/lib/validation/middleware';
import { SecurityEventService } from '@/lib/security/security-events';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    // Get request metadata for security logging
    const { ipAddress, userAgent } = validateRateLimitHeaders(request);

    // Validate input data
    const validationMiddleware = createValidationMiddleware(signupSchema);
    const validation = await validationMiddleware(request);
    
    if (!validation.success) {
      await SecurityEventService.logEvent({
        eventType: 'UNAUTHORIZED_ACCESS_ATTEMPT',
        severity: 'LOW',
        description: 'Signup failed due to validation errors',
        ipAddress,
        userAgent,
        metadata: { errors: validation.response },
      });
      return validation.response!;
    }

    const { name, email, password, organization, organizationId } = validation.data!;

    // Check if user already exists using parameterized query
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      await SecurityEventService.logEvent({
        eventType: 'UNAUTHORIZED_ACCESS_ATTEMPT',
        severity: 'LOW',
        description: 'Signup attempt with existing email',
        ipAddress,
        userAgent,
        metadata: { email },
      });
      return createErrorResponse('User with this email already exists', 400);
    }

    // Hash password with high cost factor
    const hashedPassword = await bcrypt.hash(password, 12);

    // Handle organization assignment
    let userOrganizationId: string | null = null;
    
    if (organizationId) {
      // Verify existing organization exists
      const existingOrg = await prisma.organization.findUnique({
        where: { id: organizationId },
      });
      
      if (!existingOrg) {
        return createErrorResponse('Selected organization not found', 400);
      }
      
      userOrganizationId = organizationId;
    } else if (organization) {
      // Create new organization
      try {
        const newOrg = await prisma.organization.create({
          data: {
            name: organization,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        });
        userOrganizationId = newOrg.id;
      } catch (orgError) {
        console.error('Error creating organization:', orgError);
        return createErrorResponse('Failed to create organization', 500);
      }
    }

    // Determine role based on organization
    const defaultRole = getDefaultUserRole();
    const userRole = userOrganizationId ? 'BUSINESS_USER' : defaultRole;

    // Create user with organization assignment - using parameterized insert
    const user = await prisma.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        role: userRole,
        organizationId: userOrganizationId,
        // Set email verification based on role
        emailVerified: ['ADMIN', 'USER'].includes(userRole) ? new Date() : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        organizationId: true,
        emailVerified: true,
        createdAt: true,
        organization: {
          select: {
            id: true,
            name: true,
          }
        }
      },
    });

    // Log the signup activity with sanitized data
    await logActivity({
      userId: user.id,
      action: 'SIGN_UP',
      status: 'SUCCESS',
      description: `User signed up with email: ${email}`,
      details: JSON.stringify({ 
        userId: user.id,
        email,
        role: defaultRole,
        name: name.substring(0, 50) // Limit name length in logs
      }),
      ipAddress,
      userAgent,
    });

    // User signup is already logged via activity logger above

    return createSuccessResponse({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      emailVerified: user.emailVerified,
      createdAt: user.createdAt
    }, 'User created successfully', 201);
    
  } catch (error) {
    console.error('Signup error:', error);
    
    // Log error for monitoring without exposing details
    const { ipAddress, userAgent } = validateRateLimitHeaders(request);
    await SecurityEventService.logEvent({
      eventType: 'UNAUTHORIZED_ACCESS_ATTEMPT',
      severity: 'HIGH',
      description: 'Signup failed due to server error',
      ipAddress,
      userAgent,
      metadata: { error: 'Internal server error' },
    });
    
    return createErrorResponse('Internal server error', 500);
  }
}


'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { IntegratedThreatForm } from '@/components/threat-modeling/integrated-threat-form';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { AnalyticsCharts } from '@/components/dashboard/analytics-charts';
import { Shield, FileText, Search, BarChart3, Plus, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import { ThreatModelWithDetails } from '@/lib/types';

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [recentThreatModels, setRecentThreatModels] = useState<ThreatModelWithDetails[]>([]);
  const [stats, setStats] = useState({
    totalThreatModels: 0,
    totalFindings: 0,
    totalReports: 0,
    openFindings: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
      return;
    }

    if (status === 'authenticated') {
      fetchDashboardData();
    }
  }, [status, router]);

  const fetchDashboardData = async () => {
    try {
      const [threatModelsRes, statsRes] = await Promise.all([
        fetch('/api/threat-models?limit=5'),
        fetch('/api/admin/stats')
      ]);

      if (threatModelsRes.ok) {
        const threatModelsData = await threatModelsRes.json();
        setRecentThreatModels(threatModelsData.threatModels || []);
      }

      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (status === 'loading' || isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-gradient">
          Welcome back, {session?.user?.name || 'User'}
        </h1>
        <p className="text-muted-foreground">
          Create comprehensive threat models and track security findings for your systems.
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card 
          className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:shadow-blue-500/25 hover:scale-105 hover:bg-blue-50/50 dark:hover:bg-blue-950/30"
          onClick={() => router.push('/threat-models')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Threat Models</CardTitle>
            <Shield className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalThreatModels}</div>
            <p className="text-xs text-muted-foreground">Total created • Click to view</p>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:shadow-orange-500/25 hover:scale-105 hover:bg-orange-50/50 dark:hover:bg-orange-950/30"
          onClick={() => router.push('/findings?status=OPEN')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Findings</CardTitle>
            <Search className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.openFindings}</div>
            <p className="text-xs text-muted-foreground">Requiring attention • Click to view</p>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:shadow-green-500/25 hover:scale-105 hover:bg-green-50/50 dark:hover:bg-green-950/30"
          onClick={() => router.push('/findings')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Findings</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalFindings}</div>
            <p className="text-xs text-muted-foreground">All time • Click to view</p>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:shadow-purple-500/25 hover:scale-105 hover:bg-purple-50/50 dark:hover:bg-purple-950/30"
          onClick={() => router.push('/reports')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reports</CardTitle>
            <FileText className="h-4 w-4 text-purple-600 dark:text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalReports}</div>
            <p className="text-xs text-muted-foreground">Generated • Click to view</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Threat Modeling Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardContent className="p-6">
              <IntegratedThreatForm onSuccess={fetchDashboardData} />
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="space-y-6" id="recent-models">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                  Recent Models
                </span>
                <Link href="/reports">
                  <Button variant="outline" size="sm">
                    View All
                  </Button>
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentThreatModels.length > 0 ? (
                recentThreatModels.map((model) => (
                  <div 
                    key={model.id} 
                    className="space-y-2 p-3 border rounded-lg hover:bg-muted/50 hover:shadow-md transition-all cursor-pointer"
                    onClick={() => router.push(`/findings?threatModel=${model.id}`)}
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium truncate">{model.name}</h4>
                      <span className="text-xs text-muted-foreground">
                        {new Date(model.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {model.description || 'No description'}
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>{model.findings.length} findings</span>
                      <span>{model.reports.length} reports</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No threat models yet</p>
                  <p className="text-sm">Create your first one above</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link href="/findings" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <Search className="mr-2 h-4 w-4" />
                  View All Findings
                </Button>
              </Link>
              <Link href="/reports" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <FileText className="mr-2 h-4 w-4" />
                  Generate Report
                </Button>
              </Link>
              {session?.user?.role === 'ADMIN' && (
                <Link href="/admin" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <BarChart3 className="mr-2 h-4 w-4" />
                    Admin Dashboard
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Analytics Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Analytics & Insights</h2>
            <p className="text-muted-foreground">
              Track your security posture and threat resolution progress
            </p>
          </div>
          <Link href="/findings">
            <Button variant="outline">
              <BarChart3 className="mr-2 h-4 w-4" />
              View All Findings
            </Button>
          </Link>
        </div>
        
        <AnalyticsCharts />
      </div>
    </div>
  );
}


import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/theme-provider'
import { Toaster } from '@/components/ui/sonner'
import { SessionProviderWrapper } from '@/components/providers/session-provider'
import { Sidebar } from '@/components/layout/sidebar'
import { TopBar } from '@/components/layout/top-bar'
import { SessionTimeout } from '@/components/security/session-timeout'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'BGuard Suite - Threat Modeling as a Service',
  description: 'Professional threat modeling platform with AI-powered STRIDE analysis',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <SessionProviderWrapper>
          <ThemeProvider
            attribute="class"
            defaultTheme="light"
            enableSystem
            disableTransitionOnChange
          >
            <div className="min-h-screen bg-background flex">
              <Sidebar />
              <div className="flex-1 flex flex-col">
                <TopBar />
                <main className="flex-1 container mx-auto px-4 py-8 lg:pl-8">
                  {children}
                </main>
              </div>
            </div>
            <SessionTimeout />
            <Toaster />
          </ThemeProvider>
        </SessionProviderWrapper>
      </body>
    </html>
  )
}

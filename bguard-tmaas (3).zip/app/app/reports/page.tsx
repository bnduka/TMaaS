
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { formatDistanceToNow } from 'date-fns';
import { 
  FileText, 
  AlertTriangle, 
  Download, 
  Search, 
  RefreshCw,
  FileSpreadsheet,
  Calendar,
  Shield,
  BarChart3,
  Trash2,
  Loader2
} from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';

interface ThreatModelReport {
  id: string;
  name: string;
  description?: string;
  status: 'DRAFT' | 'ANALYZING' | 'COMPLETED' | 'ARCHIVED';
  createdAt: string;
  updatedAt: string;
  findingsCount: number;
  reportsGenerated: boolean;
  user: {
    name?: string;
    email?: string;
  };
}

export default function ReportsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [threatModels, setThreatModels] = useState<ThreatModelReport[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [downloadingReports, setDownloadingReports] = useState<Set<string>>(new Set());
  const [deleteDialog, setDeleteDialog] = useState<{
    isOpen: boolean;
    reportId: string | null;
    threatModelName: string;
  }>({
    isOpen: false,
    reportId: null,
    threatModelName: ''
  });
  const [isDeletingReport, setIsDeletingReport] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
      return;
    }

    if (status === 'authenticated') {
      fetchThreatModels();
    }
  }, [status, router]);

  const fetchThreatModels = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/threat-models');
      if (!response.ok) {
        throw new Error('Failed to fetch threat models');
      }

      const data = await response.json();
      // Transform the data to include reports information
      const modelsWithReports = (data.threatModels || []).map((model: any) => ({
        id: model.id,
        name: model.name,
        description: model.description,
        status: model.status,
        createdAt: model.createdAt,
        updatedAt: model.updatedAt,
        findingsCount: model.findings?.length || 0,
        reportsGenerated: model.reports?.length > 0,
        user: model.user
      }));
      
      setThreatModels(modelsWithReports);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadReport = async (threatModelId: string, format: 'pdf' | 'excel') => {
    setDownloadingReports(prev => new Set(prev).add(`${threatModelId}-${format}`));
    
    try {
      const response = await fetch(`/api/reports/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          threatModelId,
          format,
          reportType: 'comprehensive'
        }),
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        
        const threatModel = threatModels.find(tm => tm.id === threatModelId);
        const fileName = `${threatModel?.name || 'threat-model'}_report.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
        a.download = fileName;
        
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast.success(`${format.toUpperCase()} report downloaded successfully`);
      } else {
        const data = await response.json();
        toast.error(data.error || `Failed to generate ${format.toUpperCase()} report`);
      }
    } catch (error) {
      toast.error('Network error occurred');
    } finally {
      setDownloadingReports(prev => {
        const newSet = new Set(prev);
        newSet.delete(`${threatModelId}-${format}`);
        return newSet;
      });
    }
  };

  const handleDeleteReport = async (threatModelId: string) => {
    setIsDeletingReport(true);
    
    try {
      // First, get the report ID for this threat model
      const response = await fetch(`/api/reports?threatModelId=${threatModelId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch report information');
      }
      
      const data = await response.json();
      const reports = data.reports || [];
      
      if (reports.length === 0) {
        throw new Error('No reports found for this threat model');
      }

      // Delete all reports for this threat model
      const deletePromises = reports.map((report: any) =>
        fetch(`/api/reports/${report.id}/delete`, {
          method: 'DELETE',
        })
      );

      const deleteResults = await Promise.all(deletePromises);
      
      // Check if all deletions were successful
      const failedDeletions = deleteResults.filter(result => !result.ok);
      if (failedDeletions.length > 0) {
        throw new Error(`Failed to delete ${failedDeletions.length} reports`);
      }

      // Update the threat models list to reflect that reports have been deleted
      setThreatModels(prev => 
        prev.map(model => 
          model.id === threatModelId 
            ? { ...model, reportsGenerated: false }
            : model
        )
      );

      toast.success('Reports deleted successfully');
      setDeleteDialog({ isOpen: false, reportId: null, threatModelName: '' });
      
    } catch (error: any) {
      console.error('Error deleting reports:', error);
      toast.error(error.message || 'Failed to delete reports');
    } finally {
      setIsDeletingReport(false);
    }
  };

  const openDeleteDialog = (threatModelId: string, threatModelName: string) => {
    setDeleteDialog({
      isOpen: true,
      reportId: threatModelId,
      threatModelName
    });
  };

  const closeDeleteDialog = () => {
    setDeleteDialog({ isOpen: false, reportId: null, threatModelName: '' });
  };

  const isAdmin = () => {
    return session?.user?.role === 'ADMIN' || session?.user?.role === 'BUSINESS_ADMIN';
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      COMPLETED: { variant: 'default' as const, color: 'bg-green-100 text-green-800' },
      ANALYZING: { variant: 'secondary' as const, color: 'bg-yellow-100 text-yellow-800' },
      DRAFT: { variant: 'outline' as const, color: 'bg-gray-100 text-gray-800' },
      ARCHIVED: { variant: 'outline' as const, color: 'bg-gray-100 text-gray-600' },
    };

    const config = variants[status as keyof typeof variants] || variants.DRAFT;

    return (
      <Badge variant={config.variant} className={config.color}>
        {status.toLowerCase()}
      </Badge>
    );
  };

  const filteredThreatModels = threatModels.filter(model =>
    model.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    model.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (status === 'loading' || isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-gradient">Threat Analysis Reports</h1>
        <p className="text-muted-foreground">
          Generate, view, and download comprehensive threat modeling reports in PDF and Excel formats.
        </p>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Search and Actions */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex-1 max-w-sm">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search threat models..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={fetchThreatModels}>
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      {/* Threat Models List */}
      {filteredThreatModels.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No threat models found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm ? 'No models match your search criteria.' : 'Create threat models to generate reports.'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredThreatModels.map((model) => (
            <Card key={model.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  {/* Left: Model Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-3 mb-2">
                      <Shield className="h-5 w-5 text-blue-600 flex-shrink-0" />
                      <h3 className="text-lg font-medium truncate">{model.name}</h3>
                      {getStatusBadge(model.status)}
                    </div>
                    
                    {model.description && (
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {model.description}
                      </p>
                    )}

                    <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <BarChart3 className="h-4 w-4" />
                        <span>{model.findingsCount} findings</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>{formatDistanceToNow(new Date(model.createdAt), { addSuffix: true })}</span>
                      </div>
                      {model.user.name && (
                        <div className="flex items-center space-x-1">
                          <span>by {model.user.name}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right: Action Buttons */}
                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownloadReport(model.id, 'pdf')}
                      disabled={downloadingReports.has(`${model.id}-pdf`) || model.status !== 'COMPLETED'}
                      className="flex items-center space-x-1"
                    >
                      {downloadingReports.has(`${model.id}-pdf`) ? (
                        <LoadingSpinner size="sm" />
                      ) : (
                        <Download className="h-4 w-4" />
                      )}
                      <span>PDF</span>
                    </Button>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownloadReport(model.id, 'excel')}
                      disabled={downloadingReports.has(`${model.id}-excel`) || model.status !== 'COMPLETED'}
                      className="flex items-center space-x-1"
                    >
                      {downloadingReports.has(`${model.id}-excel`) ? (
                        <LoadingSpinner size="sm" />
                      ) : (
                        <FileSpreadsheet className="h-4 w-4" />
                      )}
                      <span>Excel</span>
                    </Button>

                    {/* Delete button for admins */}
                    {isAdmin() && model.reportsGenerated && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openDeleteDialog(model.id, model.name)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        title="Delete reports"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>

                {model.status !== 'COMPLETED' && (
                  <div className="mt-4 p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      {model.status === 'ANALYZING' 
                        ? 'Reports will be available once threat analysis is completed.'
                        : 'Complete the threat analysis to generate reports.'
                      }
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialog.isOpen} onOpenChange={closeDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-600">Delete Reports</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete all reports for "{deleteDialog.threatModelName}"? 
              This action cannot be undone and will permanently remove all generated reports 
              (PDF and Excel) for this threat model.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeletingReport}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteDialog.reportId && handleDeleteReport(deleteDialog.reportId)}
              disabled={isDeletingReport}
              className="bg-red-600 hover:bg-red-700"
            >
              {isDeletingReport ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Deleting...
                </>
              ) : (
                'Delete Reports'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

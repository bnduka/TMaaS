
'use client';

import { useEffect, useState, Suspense } from 'react';
import { signOut, useSession } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, LogOut, ArrowLeft, CheckCircle } from 'lucide-react';
import Link from 'next/link';

function SignOutContent() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [isSigningOut, setIsSigningOut] = useState(false);
  const [signedOut, setSignedOut] = useState(false);

  // Check if user came from automatic sign out
  const autoSignOut = searchParams.get('auto') === 'true';

  useEffect(() => {
    // If user is not authenticated, redirect to login
    if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, router]);

  const handleSignOut = async () => {
    setIsSigningOut(true);
    try {
      await signOut({ 
        callbackUrl: '/login?signedOut=true',
        redirect: false 
      });
      setSignedOut(true);
      // Redirect after a brief moment
      setTimeout(() => {
        router.push('/login?signedOut=true');
      }, 2000);
    } catch (error) {
      console.error('Error signing out:', error);
      setIsSigningOut(false);
    }
  };

  if (status === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  if (signedOut) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900">
              <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <CardTitle className="text-2xl">Successfully Signed Out</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              You have been securely signed out of BGuard Suite.
            </p>
            <p className="text-sm text-muted-foreground">
              Redirecting to login page...
            </p>
            <LoadingSpinner size="sm" className="mx-auto" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-red-100 dark:bg-red-900">
            <LogOut className="h-8 w-8 text-red-600 dark:text-red-400" />
          </div>
          <CardTitle className="text-2xl">
            {autoSignOut ? 'Session Expired' : 'Sign Out'}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {autoSignOut && (
            <Alert>
              <AlertDescription>
                Your session has expired for security reasons. Please sign in again to continue.
              </AlertDescription>
            </Alert>
          )}
          
          <div className="text-center space-y-2">
            <p className="text-muted-foreground">
              {session?.user?.name && `Hello, ${session.user.name}`}
            </p>
            <p className="text-sm text-muted-foreground">
              {autoSignOut 
                ? 'Your session has expired. You can sign in again below.'
                : 'Are you sure you want to sign out of BGuard Suite?'
              }
            </p>
          </div>

          <div className="space-y-3">
            {!autoSignOut && (
              <Button
                onClick={handleSignOut}
                disabled={isSigningOut}
                className="w-full"
                variant="destructive"
              >
                {isSigningOut ? (
                  <>
                    <LoadingSpinner size="sm" className="mr-2" />
                    Signing Out...
                  </>
                ) : (
                  <>
                    <LogOut className="mr-2 h-4 w-4" />
                    Yes, Sign Me Out
                  </>
                )}
              </Button>
            )}
            
            <Link href="/login" className="block">
              <Button variant="outline" className="w-full">
                <Shield className="mr-2 h-4 w-4" />
                {autoSignOut ? 'Sign In Again' : 'Go to Sign In'}
              </Button>
            </Link>
            
            {!autoSignOut && (
              <Button
                variant="ghost"
                onClick={() => router.back()}
                className="w-full"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SignOutPage() {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    }>
      <SignOutContent />
    </Suspense>
  );
}

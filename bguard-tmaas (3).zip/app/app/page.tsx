
'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, FileText, Search, BarChart3, Zap, Lock, Calendar } from 'lucide-react';
import { DemoSchedulingModal } from '@/components/demo/demo-scheduling-modal';

export default function HomePage() {
  return (
    <div className="space-y-16">
      {/* Top Navigation with Demo Button */}
      <div className="flex justify-end py-4">
        <DemoSchedulingModal>
          <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200">
            <Calendar className="mr-2 h-5 w-5" />
            Schedule a Demo
          </Button>
        </DemoSchedulingModal>
      </div>

      {/* Hero Section */}
      <section className="text-center space-y-6 py-12">
        <div className="space-y-4">
          <h1 className="text-4xl md:text-6xl font-bold text-gradient bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            BGuard Suite
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground">
            Professional Threat Modeling as a Service
          </p>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Leverage AI-powered STRIDE analysis to identify security vulnerabilities and strengthen your system's defense posture.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link href="/dashboard">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Shield className="mr-2 h-5 w-5" />
              Start Threat Modeling
            </Button>
          </Link>
          <Link href="/login">
            <Button variant="outline" size="lg">
              Sign In
            </Button>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="space-y-8">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold">Advanced Threat Analysis</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our platform combines expert methodologies with cutting-edge AI to deliver comprehensive security assessments.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <Shield className="h-10 w-10 text-blue-600 mb-2" />
              <CardTitle>STRIDE Analysis</CardTitle>
              <CardDescription>
                Comprehensive threat identification using industry-standard STRIDE methodology
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Systematic analysis across Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, and Elevation of Privilege.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <FileText className="h-10 w-10 text-green-600 mb-2" />
              <CardTitle>Document Analysis</CardTitle>
              <CardDescription>
                AI-powered analysis of system documentation and architecture diagrams
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Upload PDFs, DOCX, and other documents to enhance threat analysis with contextual information.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <Search className="h-10 w-10 text-purple-600 mb-2" />
              <CardTitle>Findings Tracker</CardTitle>
              <CardDescription>
                Manage and track security findings through their entire lifecycle
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Track findings from Open → In Progress → Resolved with detailed comments and status updates.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <BarChart3 className="h-10 w-10 text-orange-600 mb-2" />
              <CardTitle>Detailed Reports</CardTitle>
              <CardDescription>
                Professional PDF and HTML reports for stakeholders and compliance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Generate comprehensive reports with executive summaries, technical details, and actionable recommendations.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <Zap className="h-10 w-10 text-yellow-600 mb-2" />
              <CardTitle>AI-Powered</CardTitle>
              <CardDescription>
                Advanced AI analysis powered by GPT-4 for intelligent threat identification
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Leverage cutting-edge AI to identify sophisticated threats and provide detailed mitigation strategies.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <Lock className="h-10 w-10 text-red-600 mb-2" />
              <CardTitle>Enterprise Security</CardTitle>
              <CardDescription>
                Built for enterprise-grade security requirements and compliance standards
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Secure data handling, audit trails, and compliance with industry security standards and frameworks.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center bg-muted rounded-lg p-12">
        <div className="space-y-4">
          <h2 className="text-3xl font-bold">Ready to Secure Your Systems?</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Join security professionals who trust BGuard Suite for comprehensive threat modeling and risk assessment.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
            <Link href="/register">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                Get Started Free
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

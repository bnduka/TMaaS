
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@bguard.com' },
    update: {},
    create: {
      email: 'admin@bguard.com',
      name: 'Admin User',
      password: adminPassword,
      role: 'ADMIN',
    },
  });

  // Create regular user
  const userPassword = await bcrypt.hash('user123', 12);
  const user = await prisma.user.upsert({
    where: { email: 'user@example.com' },
    update: {},
    create: {
      email: 'user@example.com',
      name: 'Demo User',
      password: userPassword,
      role: 'USER',
    },
  });

  // Create sample threat model
  const threatModel = await prisma.threatModel.create({
    data: {
      name: 'Corporate Web Application',
      description: 'Multi-tier web application with user management and data processing',
      prompt: 'A modern web application with user authentication, role-based access control, data processing capabilities, and API integrations. The system includes a responsive frontend, backend services, database layer, and third-party service integrations for notifications and analytics.',
      status: 'COMPLETED',
      userId: user.id,
    },
  });

  // Create sample findings
  const findings = [
    {
      title: 'Weak Authentication Implementation',
      description: 'The authentication system may be vulnerable to brute force attacks due to lack of rate limiting and weak password policies.',
      severity: 'HIGH' as const,
      strideCategory: 'SPOOFING' as const,
      recommendation: 'Implement rate limiting, enforce strong password policies, and consider multi-factor authentication.',
      status: 'OPEN' as const,
      userId: user.id,
      threatModelId: threatModel.id,
    },
    {
      title: 'Unencrypted Data Transmission',
      description: 'Sensitive data might be transmitted without proper encryption, exposing confidential information to potential attackers.',
      severity: 'CRITICAL' as const,
      strideCategory: 'INFORMATION_DISCLOSURE' as const,
      recommendation: 'Ensure all sensitive data is encrypted using TLS 1.3 and implement proper certificate management.',
      status: 'IN_PROGRESS' as const,
      userId: user.id,
      threatModelId: threatModel.id,
    },
    {
      title: 'Insufficient Input Validation',
      description: 'API endpoints may not properly validate input data, potentially leading to injection attacks.',
      severity: 'MEDIUM' as const,
      strideCategory: 'TAMPERING' as const,
      recommendation: 'Implement comprehensive input validation and sanitization for all API endpoints.',
      status: 'RESOLVED' as const,
      userId: user.id,
      threatModelId: threatModel.id,
    },
  ];

  for (const finding of findings) {
    await prisma.finding.create({ data: finding });
  }

  // Create sample report
  await prisma.report.create({
    data: {
      name: 'Web Application Security Assessment Report',
      format: 'HTML',
      content: '<h1>Security Assessment Report</h1><p>This is a sample report content for the corporate web application security assessment...</p>',
      userId: user.id,
      threatModelId: threatModel.id,
    },
  });

  // Create initial admin stats
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  await prisma.adminStats.create({
    data: {
      date: today,
      totalUsers: 2,
      totalThreatModels: 1,
      totalFindings: 3,
      totalReports: 1,
      apiCalls: 5,
    },
  });

  console.log('✅ Database seeded successfully!');
  console.log('📧 Admin user: admin@bguard.com (password: admin123)');
  console.log('📧 Demo user: user@example.com (password: user123)');
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

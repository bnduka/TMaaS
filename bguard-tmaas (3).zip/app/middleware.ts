
import { withAuth } from 'next-auth/middleware';
import { NextResponse } from 'next/server';
import { RateLimiter } from './lib/security/rate-limiter';

export default withAuth(
  async function middleware(req) {
    const { pathname } = req.nextUrl;
    const token = req.nextauth.token;

    // Rate limiting for specific endpoints
    if (pathname.startsWith('/api/')) {
      let rateLimitRule;
      let identifier;

      // Authentication endpoints
      if (pathname === '/api/auth/signin' || pathname === '/api/auth/callback/credentials') {
        rateLimitRule = RateLimiter.rules.login;
        identifier = RateLimiter.getIdentifier(req, 'ip');
      } else if (pathname === '/api/auth/signup') {
        rateLimitRule = RateLimiter.rules.signup;
        identifier = RateLimiter.getIdentifier(req, 'ip');
      } else if (pathname.startsWith('/api/auth/reset-password')) {
        rateLimitRule = RateLimiter.rules.passwordReset;
        identifier = RateLimiter.getIdentifier(req, 'ip');
      } else if (pathname.startsWith('/api/security/2fa')) {
        rateLimitRule = RateLimiter.rules.twoFactor;
        identifier = RateLimiter.getIdentifier(req, 'user', token?.sub);
      } else if (pathname.startsWith('/api/upload')) {
        rateLimitRule = RateLimiter.rules.upload;
        identifier = RateLimiter.getIdentifier(req, 'user', token?.sub);
      } else if (pathname.startsWith('/api/admin')) {
        rateLimitRule = RateLimiter.rules.admin;
        identifier = RateLimiter.getIdentifier(req, 'user', token?.sub);
      } else {
        // General API rate limiting
        rateLimitRule = RateLimiter.rules.api;
        identifier = RateLimiter.getIdentifier(req, 'user', token?.sub);
      }

      if (rateLimitRule) {
        const rateLimit = await RateLimiter.checkRateLimit(identifier, rateLimitRule);
        
        if (!rateLimit.allowed) {
          return new NextResponse(
            JSON.stringify({
              error: 'Too many requests',
              resetTime: rateLimit.resetTime,
            }),
            {
              status: 429,
              headers: {
                'Content-Type': 'application/json',
                'X-RateLimit-Remaining': '0',
                'X-RateLimit-Reset': rateLimit.resetTime.toString(),
                'Retry-After': Math.ceil((rateLimit.resetTime - Date.now()) / 1000).toString(),
              },
            }
          );
        }

        // Add rate limit headers to response
        const response = NextResponse.next();
        response.headers.set('X-RateLimit-Remaining', rateLimit.remaining.toString());
        response.headers.set('X-RateLimit-Reset', rateLimit.resetTime.toString());
      }
    }

    // Role-based access control for protected routes
    if (token) {
      const userRole = token.role as string;

      // Admin routes
      if (pathname.startsWith('/admin') && userRole !== 'ADMIN') {
        return NextResponse.redirect(new URL('/dashboard', req.url));
      }

      // Business admin routes
      if (pathname.startsWith('/business-admin') && 
          !['ADMIN', 'BUSINESS_ADMIN'].includes(userRole)) {
        return NextResponse.redirect(new URL('/dashboard', req.url));
      }

      // Check email verification requirement only for Business roles (except for verification pages)
      const requiresEmailVerification = ['BUSINESS_ADMIN', 'BUSINESS_USER'].includes(userRole);
      
      if (requiresEmailVerification &&
          !pathname.startsWith('/auth/verify') && 
          !pathname.startsWith('/api/auth/verify') &&
          !token.emailVerified) {
        return NextResponse.redirect(new URL('/auth/verify-email', req.url));
      }

      // Session timeout check
      const sessionTimeout = (token.sessionTimeout as number) || 5;
      const iat = typeof token.iat === 'number' ? token.iat : Math.floor(Date.now() / 1000);
      const sessionExpiry = new Date(iat * 1000 + sessionTimeout * 60 * 1000);
      
      if (sessionExpiry < new Date()) {
        return NextResponse.redirect(new URL('/login?expired=true', req.url));
      }
    }

    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        const { pathname } = req.nextUrl;

        // Public routes that don't require authentication
        const publicRoutes = [
          '/',
          '/login',
          '/register',
          '/auth/error',
          '/auth/verify-request',
          '/auth/verify-email',
          '/forgot-password',
          '/reset-password',
        ];

        // API routes that don't require authentication
        const publicApiRoutes = [
          '/api/auth/',
          '/api/auth/signup',
          '/api/auth/forgot-password',
          '/api/auth/reset-password',
          '/api/auth/verify-email',
        ];

        // Check if route is public
        if (publicRoutes.includes(pathname) ||
            publicApiRoutes.some(route => pathname.startsWith(route))) {
          return true;
        }

        // All other routes require authentication
        return !!token;
      },
    },
  }
);

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!_next/static|_next/image|favicon.ico|public|.*\\.png$|.*\\.jpg$|.*\\.jpeg$|.*\\.gif$|.*\\.svg$).*)',
  ],
};


require('dotenv').config();
const fs = require('fs');
const path = require('path');

// Test file upload functionality
async function testFileUpload() {
  console.log('🔍 Testing File Upload Functionality...\n');

  console.log('Environment check:');
  console.log('DATABASE_URL exists:', !!process.env.DATABASE_URL);
  console.log('NEXTAUTH_SECRET exists:', !!process.env.NEXTAUTH_SECRET);
  console.log('ABACUSAI_API_KEY exists:', !!process.env.ABACUSAI_API_KEY);

  // Test database connection
  console.log('\n1. Testing database connection...');
  try {
    const { PrismaClient } = require('@prisma/client');
    const prisma = new PrismaClient();
    
    const userCount = await prisma.user.count();
    console.log(`✓ Database connected. Users in database: ${userCount}`);
    
    // Test if demo users exist
    const adminUser = await prisma.user.findUnique({
      where: { email: 'admin@bguard.com' }
    });
    
    const regularUser = await prisma.user.findUnique({
      where: { email: 'user@example.com' }
    });
    
    console.log(`Admin user exists: ${adminUser ? '✓' : '❌'}`);
    console.log(`Regular user exists: ${regularUser ? '✓' : '❌'}`);
    
    if (!adminUser || !regularUser) {
      console.log('\n⚠️  Demo users missing! Need to seed the database.');
    }
    
    await prisma.$disconnect();
  } catch (error) {
    console.error('❌ Database connection error:', error.message);
    return;
  }

  // Test file processor directly
  console.log('\n2. Testing FileProcessor directly...');
  try {
    const { FileProcessor } = require('./lib/file-processor.ts');
    
    // Create a simple test file
    const testContent = 'This is a test document for threat modeling analysis.';
    const testFilePath = path.join(__dirname, 'test-upload.txt');
    
    if (!fs.existsSync(testFilePath)) {
      fs.writeFileSync(testFilePath, testContent);
      console.log('✓ Test file created');
    }

    // Create a mock file object
    const testFile = {
      name: 'test-upload.txt',
      type: 'text/plain',
      size: testContent.length,
      arrayBuffer: async () => Buffer.from(testContent)
    };

    const validation = FileProcessor.validateFile(testFile);
    console.log('File validation result:', validation);

    if (validation.valid) {
      try {
        // This should fail because it tries to create a DB record with invalid threatModelId
        const content = await FileProcessor.processFile(testFile, 'test-threat-model-id');
        console.log('✓ FileProcessor worked successfully');
        console.log('Extracted content length:', content.length);
      } catch (error) {
        console.error('❌ FileProcessor error:', error.message);
        console.log('This might be the root cause of the upload issue!');
      }
    }
  } catch (error) {
    console.error('❌ FileProcessor test error:', error.message);
  }

  // Test upload API with curl (simpler than node-fetch)
  console.log('\n3. Testing upload API with curl...');
  try {
    const { execSync } = require('child_process');
    const curlResult = execSync(
      'curl -X POST http://localhost:3000/api/upload -F "file=@test-upload.txt" -w "HTTP_CODE:%{http_code}"',
      { cwd: __dirname, encoding: 'utf8' }
    );
    console.log('Curl result:', curlResult);
  } catch (error) {
    console.error('❌ Curl test error:', error.message);
  }

  console.log('\n🔍 Upload Debug Test Complete\n');
}

// Add form-data dependency check
try {
  require('form-data');
  require('node-fetch');
  testFileUpload();
} catch (error) {
  console.log('Installing required dependencies...');
  const { execSync } = require('child_process');
  execSync('yarn add form-data node-fetch', { stdio: 'inherit' });
  testFileUpload();
}
